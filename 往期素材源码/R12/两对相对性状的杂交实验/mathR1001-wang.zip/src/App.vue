<template>
  <div id="app" class="noselect">
    <div class="container">
      <!--头部-->
      <h3 v-text="title" class="app_title"></h3>
      <!--视图区-->
      <div id="renderCanvas"></div>
      <ui-slider id="slider" v-model="value" :boxHeight='58' :title="false" :piecewise="true" :piecewiseLabel="true" :tooltip="false" :noBlueProcess="true" :data="[1,2,3,4]" :clickable="false"></ui-slider>
    </div>
    <ui-btn type="reset1" class="aside_reset" @click.native='reset'></ui-btn>
    <!--侧边按钮区-->
  </div>
</template>
<script>
import common from '@/common/common'; //引入公共函数;
import uiHead from '@/components/UI/uiHead'; //头部
import uiBtn from '@/components/UI/uiBtn'; //按钮
import uiSlider from '@/components/UI/uiSlider'; //滑块
const { sin, cos, PI, tan, pow, abs, sqrt } = Math;
const SCALE = 10; //放大系数
const R = 10 * sqrt(3) * SCALE; //球的半径
const SECTION_R = 15 * SCALE //截面圆的半径
const SECTION_DISY = 5 * sqrt(3) * SCALE //截面距离球心的距离
export default {
  name: 'app',
  components: {
    uiHead,
    uiBtn,
    uiSlider
  },
  data() {
    return {
      title: '单面截球',
      BtnSpaceStyle: 'flex',
      value: 1,
    }
  },
  created() {
    document.title = this.title;
    this.pre_num = 0;
  },
  mounted() {
    //禁止选择
    document.onselectstart = function() {
      return false;
    };
    this.TO = this.init();
    window.onresize = () => {
      var cW = $('canvas').width();
      var cH = $('canvas').height();
      $('canvas').css({
        'left': ($('#renderCanvas').width() - cW) / 2 + 'px',
        'top': ($('#renderCanvas').height() - cH) / 2 + 'px'
      });
    };
  },
  computed: {},
  watch: {
    value(val) {
      this.TO.watchSlider(val);
    }
  },
  methods: {
    reset() {
      this.TO.reset();
    },
    init() {
      var scene = null,
        camera = null,
        renderer = null,
        mainWidth = null,
        mainHeight = null,
        controls = null,
        isMob = null;
      isMob = /iPad|Android/g.test(navigator.userAgent);
      renderer = new THREE.WebGLRenderer({
        antialias: true
      });
      mainWidth = $('#renderCanvas').width();
      mainHeight = $('#renderCanvas').height();
      scene = new THREE.Scene();
      camera = new THREE.PerspectiveCamera(50, mainWidth / mainHeight, 1, 10000);
      camera.position.x = 0;
      camera.position.y = 200;
      camera.position.z = 1000;
      camera.lookAt(scene.position);
      scene.add(camera);
      renderer.setPixelRatio(window.devicePixelRatio);
      renderer.setClearColor(0xffffff);
      renderer.setSize(mainWidth, mainHeight);
      controls = new THREE.OrbitControls(camera, renderer.domElement);
      controls.enableDamping = true;
      controls.dampingFactor = 0.25;
      controls.enableZoom = true;
      controls.enableRotate = true;
      controls.enablePan = false;
      $("#renderCanvas").append(renderer.domElement);
      let pointPos = {
        o: [0, 0, 0],
        o1: [0, SECTION_DISY, 0],
        a: [-SECTION_R, SECTION_DISY, 0],
        c: [SECTION_R, SECTION_DISY, 0],
      };
      //专门用来存放物体的盒子
      let objectBox = {};
      //初始three场景
      var initObj = () => {
        //计算b点位置
        pointPos.b = calcPointBPos();
        //创建球
        objectBox.sphere = common.createSphere(R, { color: '#8EC4F0', opacity: 0.4, segments: 48, depthTest: false });
        scene.add(objectBox.sphere);
        // 第一阶段
        //创建圆心O
        scene.add(createPointGroup('O', 4, pointPos.o));
        //创建虚线圆心线
        scene.add(common.drawCircleLine(R, { style: 2, isLay: true, line_width: 2 }));
        //创建圆心截面
        scene.add(common.createCircle(R, { isLay: true, color: '#fff', segments: 48, opacity: 0.4, depthTest: true }));
        drawMesh();
      }
      //把所有场景需要的线和点都创建出来  然后放在对应的阶段组中，进行控制
      var drawMesh = () => {
        //第二阶段
        objectBox.step2 = new THREE.Group();
        objectBox.step2.add(createPointGroup('B', 4, pointPos.b));
        objectBox.step2.add(createPointGroup('A', 4, pointPos.a));
        objectBox.step2.add(createPointGroup('C', 4, pointPos.c));
        objectBox.step2.add(common.createStraightLine([pointPos.a, pointPos.b], 3, 3, '#00B2FF',0.1));
        objectBox.step2.add(common.createStraightLine([pointPos.a, pointPos.c], 3, 3, '#00B2FF'));
        objectBox.step2.add(common.createStraightLine([pointPos.c, pointPos.b], 3, 3, '#00B2FF'));
        let c = common.createCircle(SECTION_R, { isLay: true, color: '#fff', segments: 48, opacity: 0.4, depthTest: true, position: [0, SECTION_DISY, 0] })
        objectBox.step2.add(c);
        objectBox.step2.add(common.drawCircleLine(SECTION_R, { style: 2, isLay: true, line_width: 2, position: [0, SECTION_DISY, 0] }));
        objectBox.step2.visible = false;
        scene.add(objectBox.step2);
        //第三阶段
        objectBox.step3 = new THREE.Group();
        objectBox.step3.add(common.createStraightLine([pointPos.c, pointPos.o1], 3, 3, '#F89A00'));
        objectBox.step3.add(common.createStraightLine([pointPos.c, pointPos.o], 3, 3, '#F89A00'));
        objectBox.step3.add(common.createStraightLine([pointPos.o1, pointPos.o], 3, 3, '#F89A00'));
        objectBox.step3.visible = false;
        scene.add(objectBox.step3);
        //第四阶段
        objectBox.step4 = new THREE.Group();
        objectBox.step4.add(common.createText('d', -10, SECTION_DISY / 2 + 20, 0, '#1500FF', 48));
        objectBox.step4.add(common.createText('r', SECTION_R / 2, SECTION_DISY + 20, 0, '#1500FF', 48));
        objectBox.step4.add(common.createText('R', R / 2, SECTION_DISY / 2, 0, '#1500FF', 48));
        objectBox.step4.visible = false;
        let rightAngle = common.drawRightAngle(15);
        rightAngle.rotation.y = -objectBox.rad;
        rightAngle.position.set(...pointPos.b);
        objectBox.step4.add(rightAngle);
        scene.add(objectBox.step4);
      }
      var watchSlider = (v) => {
        if (v == 2) {
          objectBox.step2.visible = true;
          objectBox.step3.visible = objectBox.step4.visible = false;
          // objectBox.step2.scale.set(0.1,0.1,0.1);
          // objectBox.step2.children.forEach((value) => {
          //   if (value.type == 'Line2') {
          //     value.material.transparent = true;
          //     value.material.opacity = 0;
          //     console.log(value);
          //   }
          // })
          // showLineAni();
        } else if (v == 3) {
          objectBox.step3.visible = true;
          objectBox.step4.visible = false;
        } else if (v == 4) {
          objectBox.step4.visible = true;
        } else if (v == 1) {
          objectBox.step2.visible = objectBox.step3.visible = objectBox.step4.visible = false;
        }
      }
      var showLineAni = () => {
        objectBox.step2.children.forEach((value) => {
          if (value.type == 'Line2') {
            value.material.opacity += 0.01;
          }
        })
        requestAnimationFrame(showLineAni);
      }
      //计算B点位置
      var calcPointBPos = () => {
        let rad = Math.atan(18 / 24);
        objectBox.rad = rad;
        let y = SCALE * 24 * sin(rad);
        let x = SCALE * 24 * cos(rad);
        x = 15 * SCALE - x;
        return [x, SECTION_DISY, -y];
      }
      //创建坐标点的圆圈和文字
      var createPointGroup = (text, radius, position) => {
        let group = new THREE.Group();
        let point = common.createSphere(radius, { color: '#F30000', segments: 12 });
        point.position.set(...position);
        let wenzi = common.createText(text, position[0] * 1.1, position[1] + 16, position[2] * 1.1, '#000', 48);
        group.add(point, wenzi);
        return group;
      }
      var animate = () => {
        requestAnimationFrame(animate);
        renderer.clear();
        //面和实线场景
        renderer.render(scene, camera);
        //虚线场景
      };
      initObj();
      animate();
      var resetWidget = () => {};
      var TO = function() {
        return {
          reset: resetWidget,
          watchSlider
        }
      }
      return TO();
    },
  },
}

</script>
<style>
* {
  margin: 0;
  padding: 0;
}

li {
  list-style: none;
}

input,
button {
  outline: none;
  -webkit-appearance: none;
  border-radius: 0;
}


/*盒模型，padding尺寸不用再减去*/

*,
*:before,
*:after {
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
  -webkit-tap-highlight-color: transparent;
}

html,
body,
#app {
  width: 100%;
  height: 100%;
  overflow: hidden;
  font-family: "PingFang SC", "Helvetica Neue", "Helvetica", "Arial", sans-serif;
  background-color: #fff;
}

#app {
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

.noselect {
  -webkit-touch-callout: none;
  /* iOS Safari */
  -webkit-user-select: none;
  /* Chrome/Safari/Opera */
  -khtml-user-select: none;
  /* Konqueror */
  -moz-user-select: none;
  /* Firefox */
  -ms-user-select: none;
  /* Internet Explorer/Edge */
  user-select: none;
  /* Non-prefixed version, currently not supported by any browser */
}


/*ui*/

.UI-camera {
  width: 80px;
  height: 80px;
  cursor: this.pointer;
}


/*内容区*/

.container {
  position: relative;
  width: 100%;
  float: left;
  height: 100%;
}

.container h3 {
  font-size: 24px;
  color: #000;
  line-height: 1.0;
  padding: 24px;
  font-weight: normal;
}

.app_aside {
  float: left;
  width: 280px;
  background-color: #F7F7F7;
  height: 100%;
  box-shadow: -0.5px 0 0 rgba(0, 0, 0, 0.12);
}

#renderCanvas {
  width: 100%;
  height: calc(100% - 72px);
  outline: none;
  position: relative;
  overflow: hidden;
}

canvas {
  position: absolute;
}

.btn_space {
  padding: 20px;
  width: 100%;
  height: calc(100% - 80px);
  clear: both;
  /*display: flex;*/
  /*align-items: center;*/
  justify-content: center;
  flex-direction: column;
  overflow: hidden;
  overflow-y: auto;
}

#app .aside_reset {
  position: fixed;
  right: 0;
  top: 0;
}


/*滑条样式*/

#slider {
  position: absolute;
  bottom: 24px;
  left: 50%;
  transform: translateX(-50%);
  width: 80% !important;
}

</style>
