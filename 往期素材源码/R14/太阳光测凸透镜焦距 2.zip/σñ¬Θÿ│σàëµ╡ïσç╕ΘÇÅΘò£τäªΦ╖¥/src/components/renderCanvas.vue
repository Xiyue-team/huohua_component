<template>
    <div class="renderCanvas" id="renderCanvas" ref="renderCanvas">
    <img src="@/components/UI/bgT.png" style="width:100%;height:100%; position:absolute;"> </div>
</template>
<script>
/* eslint-disable */
/* global THREE:true */
import common from '@/assets/js/common.js';
import Bus from '@/assets/js/Bus.js';
import uiBtn from '@/components/UI/uiBtn';
export default {
    props: {},
    components: { uiBtn },
    data() {
        return {
            ismob: false
        }
    },
    created() {
        this.canSlide = false;
        this.isHidden = false;
    },
    watch: {},
    mounted() {
        this.mark = true
        this.angular = [{ 'x': 5, 'y': 0 }, { 'x': -5, 'y': 0 }, { 'x': 0, 'y': 10 }] //箭头
        this.ally = 36.51
        this.allX = this.ally / 1.732
        this.planeN = -235
        this.multiple = 5
        this.shinePosY = 150
        let numl = (this.ally + 180) / 60 * 1.414
        numl = numl.toFixed(1)
        this.redMouseImg = new THREE.TextureLoader().load('static/img/bgT.png');
        this.floorImg = new THREE.TextureLoader().load('static/img/floor.png');
        this.glassImg = new THREE.TextureLoader().load('static/img/glass.png');
        this.sunImg = new THREE.TextureLoader().load('static/img/sun.png');
        this.lightImg = new THREE.TextureLoader().load('static/img/light.png');
        this.arrows = new THREE.TextureLoader().load('static/img/Triangle.png');
        let renderCanvas = this.$refs.renderCanvas;
        let w = window.innerWidth;
        let h = window.innerHeight;
        if (w < 500 || h < 500) {
            if (w < h) {
                [w, h] = [h, w];
                
            }
            this.width = w
            this.height = h
        } else {
            this.width = renderCanvas.clientWidth
            this.height = renderCanvas.clientHeight
            if (this.width < this.height) {
                [this.width, this.height] = [this.height, this.width];
                
            }
        }

        this.left = renderCanvas.getBoundingClientRect().left;
        this.top = renderCanvas.getBoundingClientRect().top;
        this.renderer = new THREE.WebGLRenderer({
            antialias: true,
            alpha: true
        });
        this.scene = new THREE.Scene();
        this.camera = new THREE.PerspectiveCamera(50, this.width / this.height, 1, 10000);
        this.camera.position.set(0, 0, 800);
        this.renderer.setPixelRatio(window.devicePixelRatio);
        this.renderer.setClearColor(0xffffff, 0.0);
        this.renderer.setSize(this.width, this.height);
        Bus.$emit('long', numl)
        Bus.$on('canvas', (e) => {
            window.resolution = new THREE.Vector2(this.width, this.height);
            this.camera.aspect = this.width / this.height;
            this.camera.updateProjectionMatrix();
            this.renderer.setSize(this.width, this.height);
            this.renderer.setSize(this.width, this.height, false);
        })
        this.scene.add(this.camera);
        renderCanvas.appendChild(this.renderer.domElement);
        $("canvas").css("position","absolute");
        $("canvas").css("z-index","1");
        this.selectobjs = [];
        this.selectobj = null;
        this.raycaster = new THREE.Raycaster();
        this.plane = new THREE.Plane();
        this.offset = new THREE.Vector3();
        this.intersection = new THREE.Vector3();
        this.mouse = new THREE.Vector2();
        this.INTERSECTED = null;
        this.mousedownflag = false;
        this.init();
        this.animate();
        this.createLine();
        this.renderer.domElement.addEventListener('mousedown', this.onDocumentMouseDown, false);
        this.renderer.domElement.addEventListener('touchstart', this.onDocumentTouchStart, false);
    },
    methods: {
        // 初始化场景
        init() {
            this.geometryPlan = new THREE.PlaneGeometry(1700, 750);
            this.materialPlan = new THREE.MeshBasicMaterial({
                map: this.redMouseImg,
                overdraw: 0.2,
            });
            this.meshPlan = new THREE.Mesh(this.geometryPlan, this.materialPlan);
            // this.scene.add(this.meshPlan);

            this.geometryFloor = new THREE.PlaneGeometry(600, 90);
            this.materialFloor = new THREE.MeshBasicMaterial({
                map: this.floorImg,
                overdraw: 0.2,
                transparent: true,
                depthTest: false
            });
            this.meshFloor = new THREE.Mesh(this.geometryFloor, this.materialFloor);
            this.scene.add(this.meshFloor)
            this.meshFloor.position.y = -235
            this.meshFloor.position.x = -150

            this.glassPlan = new THREE.PlaneGeometry(150, 75);
            this.glassMaterial = new THREE.MeshBasicMaterial({
                map: this.glassImg,
                overdraw: 0.2,
                transparent: true,
                depthTest: false

            })
            this.glassMesh = new THREE.Mesh(this.glassPlan, this.glassMaterial)
            this.scene.add(this.glassMesh)
            this.glassMesh.name = 'glass'
            this.glassMesh.position.x = -150
            this.glassMesh.position.y = -150
            // this.selectobjs.push(this.glassMesh)

            this.glassPlan1 = new THREE.PlaneGeometry(200, 200);
            this.glassMaterial1 = new THREE.MeshBasicMaterial({
                overdraw: 0.2,
                transparent: true,
                opacity:0,
                depthTest: false

            })
            this.glassMesh1 = new THREE.Mesh(this.glassPlan1, this.glassMaterial1)
            this.scene.add(this.glassMesh1)
            this.glassMesh1.name = 'glass1'
            this.glassMesh1.position.x = -150
            this.glassMesh1.position.y = -150
            this.selectobjs.push(this.glassMesh1)

            this.sunPlane = new THREE.PlaneGeometry(180, 180);
            this.sunMaterial = new THREE.MeshBasicMaterial({
                map: this.sunImg,
                overdraw: 0.2,
                transparent: true,
                opacity: 0.99,
                depthTest: false

            })
            this.lightPlane = new THREE.PlaneGeometry(20, 8)
            this.lightMaterial = new THREE.MeshBasicMaterial({
                map: this.lightImg,
                overdraw: 0.2,
                transparent: true,
                depthTest: false
            })
            this.lightMesh = new THREE.Mesh(this.lightPlane, this.lightMaterial)
            this.lightMesh.position.set(-36, -240, 5)
            this.scene.add(this.lightMesh)
            this.sunMesh = new THREE.Mesh(this.sunPlane, this.sunMaterial)
            this.scene.add(this.sunMesh);
            this.sunMesh.position.set(130, 280, 0)
            this.shinese = this.shines()
            let numl = 6.25
            numl = numl.toFixed(1)
            Bus.$emit('long', numl)

            Bus.$on('multiple', (e) => {
                this.multiple = e
                let x, y
                if (this.multiple === 10) {
                    this.ally10 = -83.965
                    this.allX10 = this.ally10 / 1.732
                    y = this.ally10
                    x = this.allX10
                }
                if (this.multiple === 15) {
                    this.ally15 = -117
                    this.allX15 = this.ally15 / 1.732
                    y = this.ally15
                    x = this.allX15
                }
                if (this.multiple === 5) {
                    this.ally5 = 36.51
                    this.allX5 = this.ally5 / 1.732
                    y = this.ally5
                    x = this.allX5
                }
                this.scene.remove(this.lineGroup, this.triangle, this.triangle1)
                this.lineGroup = new THREE.Group()
                this.createShines(x, y)
                // this.lightMesh.scale.set(1, 1, 1)
                // this.createLine()
            })
            Bus.$on('visebalLine', (e) => {
                if (e) {
                    this.mark = true
                    this.scene.add(this.lineGroup, this.triangle, this.triangle1, this.shine1, this.shine2);
                } else {
                    this.mark = false
                    this.scene.remove(this.lineGroup, this.triangle, this.triangle1, this.shine1, this.shine2)
                }
            })
            Bus.$on('reset', (e) => {
                this.multiple = 5
                this.ally = 36.51
                this.allX = this.ally / 1.732
                this.scene.remove(this.lineGroup, this.triangle, this.triangle1, this.shine1, this.shine2)
                this.createLine()
            })

        },
        createLine() {
            this.lineGroup = new THREE.Group()
            this.shine1 = common.unitLine({
                width: 2,
                color: '#F7881E'
            });
            this.shine2 = common.unitLine({
                width: 2,
                color: '#F7881E'
            });
            this.refractionLine1 = common.unitLine({
                width: 2,
                color: '#F7881E'
            });
            this.refractionLine2 = common.unitLine({
                width: 2,
                color: '#F7881E'
            });
            this.scene.add(this.shine1, this.shine2)
            this.glassMesh.position.set(this.allX, this.ally, 10)
            this.glassMesh1.position.set(this.allX, this.ally, 10)
            this.shine1 = common.scaleLine([this.allX - 50, this.ally + 10, 10], [this.shinePosY - 90, this.shinese[0], 10], this.shine1)
            this.shine2 = common.scaleLine([this.allX - 20, this.ally, 10], [this.shinePosY - 65, this.shinese[1], 10], this.shine2)
            let numl = (this.ally + 180) / 60 * 1.732
            numl = numl.toFixed(2)
            numl = Math.round(numl * 10) / 10
            Bus.$emit('long', numl)
            this.createShines(this.allX, this.ally)

        },
        createShines(x, y) {
            this.arrowsPlan = new THREE.PlaneGeometry(20, 22);
            this.arrowsMaterial = new THREE.MeshBasicMaterial({
                map: this.arrows,
                overdraw: 0.2,
                transparent: true,
                depthTest: false

            })
            this.arrowsPlan1 = new THREE.PlaneGeometry(20, 22);
            this.arrowsMaterial1 = new THREE.MeshBasicMaterial({
                map: this.arrows,
                overdraw: 0.2,
                transparent: true,
                depthTest: false

            })
            this.triangle = new THREE.Mesh(this.arrowsPlan, this.arrowsMaterial)
            this.triangle1 = new THREE.Mesh(this.arrowsPlan1, this.arrowsMaterial1)
            let rxs = this.refractionStar(this.ally)
            let rxe = this.refractionEnd(y, y / 1.732)
            let rx = this.refraction()
            let rxr = Math.abs(rx.x1 - rx.x2) / 20 + 1
            this.lightMesh.scale.set(rxr, rxr, 1)
            this.lightMesh.position.set((rx.x1 + rx.x2) / 2, -240, 5)
            this.angulars()
            this.triangle.position.set(rx.x3, this.ally - 40, 10)
            this.triangle1.position.set(rx.x4, this.ally - 50, 10)
            this.refractionLine1 = common.scaleLine([this.allX - 58, rxs[0], 10], [rx.x1, -235, 0], this.refractionLine1)
            this.refractionLine2 = common.scaleLine([this.allX - 28, rxs[1], 10], [rx.x2, -235, 0], this.refractionLine2)
            this.lineGroup.add(this.refractionLine1, this.refractionLine2)
            if (this.mark) {
                this.scene.add(this.lineGroup, this.triangle, this.triangle1);
            }
        },
        shines() {
            let y1 = 1.732 * (this.shinePosY - 90 - this.allX + 50) + this.ally + 10
            let y2 = 1.732 * (this.shinePosY - 65 - this.allX + 20) + this.ally
            return [y1, y2]
        },
        refractionStar(y) {
            let y1 = 1.732 * (-58 + 50) + y + 10
            let y2 = 1.732 * (-28 + 20) + y
            return [y1, y2]
        },
        refractionEnd(y, x) {
            let x1 = (-235 - y + 5) / 1.732 + x - 35
            return x1
        },
        refraction() {
            let x1 = 0;
            let x2 = 0;
            let x3 = 0;
            let x4 = 0;
            let rxs1 = this.refractionStar(this.ally)
            if (this.multiple === 5) {
                let rxe = this.refractionEnd(36.51, 36.51 / 1.732)
                let rxs = this.refractionStar(36.51)
                let k1 = (rxs[0] + 235) / (36.51 / 1.732 - 58 - rxe)
                let k2 = (rxs[1] + 235) / (36.51 / 1.732 - 28 - rxe)
                x1 = (-235 - rxs1[0]) / k1 + this.allX - 58
                x2 = (-235 - rxs1[1]) / k2 + this.allX - 28
                x3 = (this.ally - 40 - rxs1[0]) / k1 + this.allX - 58
                x4 = (this.ally - 50 - rxs1[1]) / k2 + this.allX - 28
            }
            if (this.multiple === 10) {
                let rxe = this.refractionEnd(this.ally10, this.ally10 / 1.732)
                let rxs = this.refractionStar(this.ally10)
                let k1 = (rxs[0] + 235) / (this.ally10 / 1.732 - 58 - rxe)
                let k2 = (rxs[1] + 235) / (this.ally10 / 1.732 - 28 - rxe)
                x1 = (-235 - rxs1[0]) / k1 + this.allX - 58
                x2 = (-235 - rxs1[1]) / k2 + this.allX - 28
                x3 = (this.ally - 40 - rxs1[0]) / k1 + this.allX - 58
                x4 = (this.ally - 50 - rxs1[1]) / k2 + this.allX - 28
            }
            if (this.multiple === 15) {
                let rxe = this.refractionEnd(this.ally15, this.ally15 / 1.732)
                let rxs = this.refractionStar(this.ally15)
                let k1 = (rxs[0] + 235) / (this.ally15 / 1.732 - 58 - rxe)
                let k2 = (rxs[1] + 235) / (this.ally15 / 1.732 - 28 - rxe)
                x1 = (-235 - rxs1[0]) / k1 + this.allX - 58
                x2 = (-235 - rxs1[1]) / k2 + this.allX - 28
                x3 = (this.ally - 40 - rxs1[0]) / k1 + this.allX - 58
                x4 = (this.ally - 50 - rxs1[1]) / k2 + this.allX - 28
            }
            let x = { 'x1': x1, 'x2': x2, 'x3': x3, 'x4': x4 }
            return x
        },
        angulars() {
            if (this.multiple === 5) {
                this.triangle.rotateZ(Math.atan(2.0451252812409013) + Math.PI / 2)
                this.triangle1.rotateZ(Math.atan(1.6015874875284424) + Math.PI / 2)
            }
            if (this.multiple === 10) {
                this.triangle.rotateZ(Math.atan(2.400343016412583) + Math.PI / 2)
                this.triangle1.rotateZ(Math.atan(1.502247915072806) + Math.PI / 2)
            }
            if (this.multiple === 15) {
                this.triangle.rotateZ(Math.atan(2.702113170411677) + Math.PI / 2)
                this.triangle1.rotateZ(Math.atan(1.4415892075061536) + Math.PI / 2)
            }
        },
        animate() {
            requestAnimationFrame(this.animate);
            if (this.count) {
                this.count = ++this.count % 2;
                return;
            } else {
                this.count++;
            }
            this.renderer.clear();
            this.renderer.render(this.scene, this.camera);
        },
        onDocumentMouseDown(event) {
            event.preventDefault();
            let mouse = {};
            mouse.x = ((event.clientX - this.left) / this.width) * 2 - 1;
            mouse.y = -((event.clientY - this.top) / this.height) * 2 + 1;
            this.mousedownHandle(mouse);
        },
        onDocumentTouchStart(event) {
            event.preventDefault();
            let mouse = {};
            mouse.x = ((event.touches[0].pageX - this.left) / this.width) * 2 - 1;
            mouse.y = -((event.touches[0].pageY - this.top) / this.height) * 2 + 1;
            this.mousedownHandle(mouse);
        },
        onDocumentMouseMove(event) {
            event.preventDefault();
            let mouse = {};
            mouse.x = ((event.clientX - this.left) / this.width) * 2 - 1;
            mouse.y = -((event.clientY - this.top) / this.height) * 2 + 1;
            this.mouseMoveHandle(mouse);
        },
        onDocumentTouchMove(event) {
            event.preventDefault();
            let mouse = {};
            mouse.x = ((event.touches[0].pageX - this.left) / this.width) * 2 - 1;
            mouse.y = -((event.touches[0].pageY - this.top) / this.height) * 2 + 1;
            this.mouseMoveHandle(mouse);
        },
        onDocumentMouseUp(event) {
            event.preventDefault();
            this.mousedownflag = false;
            this.selectobj = null;
            this.renderer.domElement.removeEventListener('mousemove', this.onDocumentMouseMove);
            window.removeEventListener('mouseup', this.onDocumentMouseUp);
            this.renderer.domElement.removeEventListener('touchmove', this.onDocumentTouchMove);
            this.renderer.domElement.removeEventListener('touchend', this.onDocumentMouseUp);
        },
        mousedownHandle(mouse) {
            this.raycaster.setFromCamera(mouse, this.camera);
            let intersects = this.raycaster.intersectObjects(this.selectobjs);
            if (intersects.length > 0) {
                this.selectobj = intersects[0].object;
                if (this.selectobj.name === 'glass1') {
                    this.mousedownflag = true;
                    this.renderer.domElement.addEventListener('mousemove', this.onDocumentMouseMove, false);
                    window.addEventListener('mouseup', this.onDocumentMouseUp, false);
                    this.renderer.domElement.addEventListener('touchmove', this.onDocumentTouchMove, false);
                    this.renderer.domElement.addEventListener('touchend', this.onDocumentMouseUp, false);
                }
            } else {
                Bus.$emit('msg', 1)
            }
        },
        mouseMoveHandle(mouse) {
            this.raycaster.setFromCamera(mouse, this.camera);
            let intersects = this.raycaster.intersectObjects(this.selectobjs);
            if (intersects.length > 0) {
                if (this.INTERSECTED !== intersects[0].object) {
                    this.INTERSECTED = intersects[0].object;
                    this.plane.setFromNormalAndCoplanarPoint(this.camera.getWorldDirection(this.plane.normal), this.INTERSECTED.position);
                }
            }
            if (this.mousedownflag) {
                if (this.raycaster.ray.intersectPlane(this.plane, this.intersection)) {
                    let obj = this.intersection.sub(this.offset),
                        x, y;
                    x = obj.x;
                    y = obj.y;
                    x = Math.tan(Math.PI / 6) * y
                    if (y >= -180 && y < 160) {
                        this.allX = x
                        this.ally = y
                        let numl = (this.ally + 180) / 60 * 1.732
                        numl = numl.toFixed(1)
                        Bus.$emit('long', numl)
                        this.shine1 = common.scaleLine([this.allX - 50, this.ally + 10, 10], [this.shinePosY - 90, this.shinese[0], 10], this.shine1)
                        this.shine2 = common.scaleLine([this.allX - 20, this.ally, 10], [this.shinePosY - 65, this.shinese[1], 10], this.shine2)
                        this.INTERSECTED.position.set(x, y, 10)
                        this.glassMesh.position.set(x, y, 10)
                        let rxs = this.refractionStar(this.ally)
                        let rxe = this.refractionEnd(this.ally, this.allX)
                        let rx1 = this.refraction().x1
                        let rx2 = this.refraction().x2
                        let rx3 = this.refraction().x3
                        let rx4 = this.refraction().x4
                        this.triangle.position.set(rx3, this.ally - 40, 10)
                        this.triangle1.position.set(rx4, this.ally - 50, 10)
                        let rxr = Math.abs(rx1 - rx2) / 20 + 1
                        this.lightMesh.scale.set(rxr, rxr, 1)
                        this.lightMesh.position.set((rx1 + rx2) / 2, -240, 5)

                        this.refractionLine1 = common.scaleLine([this.allX - 58, rxs[0], 10], [rx1, -235, 0], this.refractionLine1)
                        this.refractionLine2 = common.scaleLine([this.allX - 28, rxs[1], 10], [rx2, -235, 0], this.refractionLine2)
                    }
                }
            }
        }
    }
}

</script>
<style scoped>
canvas {
    position:absolute;
    outline: none;
}

.renderCanvas {
    width: 100%;
    height: 100%;
    position: absolute;
    background-size: 100% 100%;
    background-repeat: no-repeat;
}

.a {
    width: 100%;
    height: 100%;
    position: absolute;
    z-index: 0
}

img {
    pointer-events: none;
    z-index: 0
}


</style>
